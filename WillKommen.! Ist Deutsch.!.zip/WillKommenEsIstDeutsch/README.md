# Herzlich willkommen! Los lernen Deutch durch diese App.

App for personal German Language training

Dependencies installed:
1. Calligraphy - https://github.com/InflationX/Calligraphy
